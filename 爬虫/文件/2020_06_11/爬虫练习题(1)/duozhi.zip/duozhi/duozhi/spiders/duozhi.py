# -*- coding: utf-8 -*-
import scrapy
import bs4
from ..items import DuozhiItem


class DangdangBookSpider(scrapy.Spider):
    name = 'duozhi'
    allowed_domains = ['duozhi.com']
    start_urls = ['http://www.duozhi.com/']

    def parse(self, response):
        soup = bs4.BeautifulSoup(response.text, 'html.parser')
        elements = soup.find_all('div', class_="post-item")
        for element in elements:
            title = element.find('a',class_='post-title').text
            content = element.find('p',class_='post-desc').text
            item = DuozhiItem()
            item['title'] = title
            item['content'] = content


            yield item
